from .suite import Tester

from .sum import get_instance
from .math import get_instance
